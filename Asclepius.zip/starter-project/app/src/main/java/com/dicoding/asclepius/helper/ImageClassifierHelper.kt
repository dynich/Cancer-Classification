package com.dicoding.asclepius.helper

import android.graphics.Bitmap
import android.media.Image
import android.net.Uri


class ImageClassifierHelper() {

    private fun setupImageClassifier() {
        // TODO: Menyiapkan Image Classifier untuk memproses gambar.
    }

    fun classifyStaticImage(imageUri: Uri) {
        // TODO: mengklasifikasikan imageUri dari gambar statis.
    }

}